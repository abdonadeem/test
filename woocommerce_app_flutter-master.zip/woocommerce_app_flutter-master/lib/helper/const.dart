import 'package:woocommerce_app/helper/woocommerce_api.dart';

class Const {
  static WooCommerceAPI wc_api = new WooCommerceAPI(
      "your_host_name", "your_consumer_key", "your_secret_key");
}
